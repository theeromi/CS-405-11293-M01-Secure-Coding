#include <iostream>
#include <exception>  // For std::exception and std::runtime_error
#include <stdexcept>  // For std::runtime_error
#include <string>     // For std::string

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    CustomException(const std::string& message) : msg(message) {}
    
    virtual const char* what() const noexcept override {
        return msg.c_str();
    }

private:
    std::string msg;
};

bool do_even_more_custom_application_logic() {
    // Throw a standard exception for demonstration
    throw std::runtime_error("Standard exception thrown in do_even_more_custom_application_logic");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        // Wrap the call to do_even_more_custom_application_logic() with an exception handler
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catch std::exception, display a message and the exception.what()
        std::cerr << "Caught an exception in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throw a custom exception
    throw CustomException("Custom exception thrown in do_custom_application_logic");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    if (den == 0) {
        // Throw an exception to deal with divide by zero errors
        throw std::runtime_error("Division by zero error in divide function");
    }
    return (num / den);
}

void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        // Capture ONLY the exception thrown by divide
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        // Handle division by zero error
        std::cerr << "Caught an exception in do_division: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        // Call functions that may throw exceptions
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        // Catch custom exception
        std::cerr << "Caught a custom exception in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        // Catch other standard exceptions
        std::cerr << "Caught a standard exception in main: " << e.what() << std::endl;
    }
    catch (...) {
        // Catch all other exceptions
        std::cerr << "Caught an unknown exception in main" << std::endl;
    }

    return 0;
}
